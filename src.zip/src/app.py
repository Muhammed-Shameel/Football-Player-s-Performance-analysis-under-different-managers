import pandas as pd
import pickle
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify
import os
import random
import warnings
import json
from collections import defaultdict
import datetime
import calendar
import base64
import hashlib
from io import BytesIO

# Suppress warnings
warnings.filterwarnings("ignore")

app = Flask(__name__, 
            template_folder='../templates',
            static_folder='../static')

# Load data with error handling
try:
    player_data = pd.read_excel('../data/player.xlsx')
except Exception as e:
    print(f"Error loading player.xlsx: {e}")
    player_data = pd.DataFrame()

# Load df_model.csv (main data source for abilities, impact score, and best tactic)
try:
    df_model = pd.read_csv('../data/df_model.csv')
except Exception as e:
    print(f"Error loading df_model.csv: {e}")
    df_model = pd.DataFrame()

# Load player_stat.csv as fallback for player data
player_stat_data = pd.DataFrame()
try:
    player_stat_data = pd.read_csv('../data/player_stat.csv')
except Exception as e:
    print(f"Error loading player_stat.csv: {e}")

# Keep tactic_data as alias for backward compatibility
tactic_data = df_model

try:
    team_data = pd.read_excel('../data/team.xlsx')
except Exception as e:
    print(f"Error loading team.xlsx: {e}")
    team_data = pd.DataFrame()

try:
    manager_data = pd.read_excel('../data/manager.xlsx')
except Exception as e:
    print(f"Error loading manager.xlsx: {e}")
    manager_data = pd.DataFrame()

try:
    manager_formation_data = pd.read_excel('../data/manager_formation.xlsx')
except Exception as e:
    print(f"Error loading manager_formation.xlsx: {e}")
    manager_formation_data = pd.DataFrame()

# Load manager tactics mapping
try:
    with open('../data/manager_tactics.json', 'r') as f:
        manager_tactics = json.load(f)
except Exception as e:
    print(f"Error loading manager_tactics.json: {e}")
    manager_tactics = {}

# Available models with correct file names
MODELS = {
    'Random Forest': 'randomforest_best.pkl',
    'Gradient Boosting': 'gradientboost_best.pkl',
    'XGBoost': 'xgboost_best.pkl',
    'Neural Network': 'neuralnet_best.pkl',
    'SVM': 'svm_best_model.pkl'
}

# Global model performance scores (F1 scores)
MODEL_PERFORMANCE = {
    'Random Forest': 0.64,
    'Gradient Boosting': 0.65,
    'XGBoost': 0.66,
    'Neural Network': 0.62,
    'SVM': 0.65
}

# Determine best model globally
BEST_MODEL = max(MODEL_PERFORMANCE.keys(), key=lambda k: MODEL_PERFORMANCE[k])

# Load label encoder if it exists
label_encoder = None
try:
    with open('label_encoder.pkl', 'rb') as f:
        label_encoder = pickle.load(f)
except Exception as e:
    print(f"Warning: Could not load label_encoder.pkl: {e}")

# Get unique players with proper names
players_df = pd.DataFrame()
if not player_data.empty:
    try:
        players_df = player_data[['Player_ID', 'Common_Name']].drop_duplicates()
        # Manual column renaming
        players_df.columns = ['Player_ID', 'Player_Name']
    except Exception as e:
        print(f"Error processing player data: {e}")
        players_df = pd.DataFrame({'Player_ID': pd.Series([], dtype='str'), 'Player_Name': pd.Series([], dtype='str')})
elif not player_stat_data.empty:
    # Fallback to player_stat_data if player.xlsx is not available
    try:
        players_df = player_stat_data[['Player_ID', 'Squad']].drop_duplicates()
        # Rename columns and create player names
        players_df.columns = ['Player_ID', 'Player_Name']
        # Add "Player" prefix to player names
        # Convert to list, process, then back to Series to avoid linter error
        player_names = players_df['Player_Name'].tolist()
        processed_names = [f"Player {x}" if pd.notna(x) else "Unknown Player" for x in player_names]
        players_df['Player_Name'] = pd.Series(processed_names, dtype='str')
    except Exception as e1:
        print(f"Error processing player_stat data: {e1}")
        players_df = pd.DataFrame({'Player_ID': pd.Series([], dtype='str'), 'Player_Name': pd.Series([], dtype='str')})
import os

# Get unique years from df_model
years = []
if not df_model.empty:
    try:
        years = sorted(df_model['Year'].unique())
    except Exception as e:
        print(f"Error getting years from df_model: {e}")
        years = []

# Get tactical component columns globally
tactic_columns = []
if not df_model.empty:
    tactic_columns = [col for col in df_model.columns if col.startswith('Tactic_Component_')]

def generate_player_image(player_id, player_name):
    """
    Generate a white background image with the player's name centered.
    Returns the path to the generated image.
    """
    try:
        # Import PIL modules here to avoid issues if not installed
        from PIL import Image, ImageDraw, ImageFont
        import os
        
        # Create the image file path
        image_filename = f"{player_id}_img.png"
        image_path = os.path.join('../static/images', image_filename)
        
        # Create a white background image (200x200 pixels)
        width, height = 200, 200
        image = Image.new('RGB', (width, height), 'white')
        draw = ImageDraw.Draw(image)
        
        # Try to use a better font, fallback to default if not available
        try:
            # Try to use a better font (this will depend on the system)
            font = ImageFont.truetype("arial.ttf", 24)
        except:
            try:
                font = ImageFont.truetype("DejaVuSans.ttf", 24)
            except:
                # Fallback to default font
                font = ImageFont.load_default()
        
        # Prepare the text (player name)
        if not player_name or player_name.strip() == "":
            text = player_id
        else:
            text = player_name
            
        # Calculate text size and position for centering
        try:
            # For newer PIL versions
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
        except:
            # For older PIL versions
            text_width, text_height = 200, 24  # Default values
        
        # Calculate position to center the text
        x = (width - text_width) // 2
        y = (height - text_height) // 2
        
        # Draw the text in black color
        draw.text((x, y), text, fill='black', font=font)
        
        # Save the image
        image.save(image_path, 'PNG')
        
        # Return the relative path that can be used in HTML (with /static prefix)
        return f"/static/images/{image_filename}"
        
    except Exception as e:
        print(f"Error generating player image: {e}")
        # Return a default image path or None
        return "/static/images/default.png"

def get_shared_tactical_recommendations(player_id, model_name='XGBoost', year=None):
    """Shared function for getting tactical recommendations - used by both main dashboard and tactical components"""
    try:
        print(f"[get_shared_tactical_recommendations] Request: player_id={player_id}, model={model_name}, year={year}")
        
        # Check if data files are loaded
        if df_model.empty:
            return {'error': 'Model data not available - df_model.csv not loaded'}
        
        # Check if player exists in df_model
        player_model_data = df_model[df_model['Player_ID'] == player_id]
        if len(player_model_data) == 0:
            return {'error': f'Player {player_id} not found in model data'}
        
        # Convert year to int if provided
        year_int = None
        if year and str(year).strip() and str(year).lower() not in ['all', 'all years']:
            try:
                year_int = int(year)
                print(f"[get_shared_tactical_recommendations] Using year filter: {year_int}")
            except ValueError:
                return {'error': f'Invalid year format: {year}'}
        
        # Filter by year if specified
        if year_int:
            year_data = player_model_data[player_model_data['Year'] == year_int]
            if len(year_data) == 0:
                return {'error': f'No data found for player {player_id} in year {year_int}'}
            player_model_data = year_data
        
        print(f"[get_shared_tactical_recommendations] Found {len(player_model_data)} records for player {player_id}")
        
        # Get tactical recommendations
        recommendations = []
        best_tactic_data = None
        
        # Get tactical component columns
        tactic_columns_local = [col for col in df_model.columns if col.startswith('Tactic_Component_')]
        
        for component in tactic_columns_local:
            try:
                value = round(float(player_model_data[component].mean()), 2)
                recommendations.append({
                    'component': component,
                    'value': value,
                    'impact': value
                })
            except Exception:
                continue
        
        # Find best tactic from recommendations
        if recommendations:
            best_recommendation = max(recommendations, key=lambda x: x['value'])
            best_tactic = best_recommendation['component']
            tactic_value = best_recommendation['value']
            best_tactic_data = {
                'component': best_tactic,
                'value': tactic_value,
                'formation': get_formation_for_component(best_tactic),
                'description': get_tactic_description(best_tactic)
            }
        
        print(f"[get_shared_tactical_recommendations] Generated {len(recommendations)} recommendations")
        if best_tactic_data:
            print(f"[get_shared_tactical_recommendations] Best tactic: {best_tactic_data['component']}, value: {best_tactic_data['value']}")
        
        return {
            'recommendations': recommendations,
            'best_tactic_data': best_tactic_data,
            'player_model_data': player_model_data
        }
        
    except Exception as e:
        print(f"[get_shared_tactical_recommendations] Error: {e}")
        return {'error': f'Error generating tactical recommendations: {str(e)}'}

def load_model(model_name):
    """Load the specified model - with fallback for corrupted models"""
    model_path = MODELS.get(model_name)
    if model_path and os.path.exists(model_path):
        try:
            with open(model_path, 'rb') as f:
                model = pickle.load(f)
            return model
        except Exception as e:
            print(f"Error loading model {model_name}: {e}")
            # Return None to indicate model loading failed
            return None
    return None

def get_player_features(player_id, year=None):
    """Get features for a specific player, optionally filtered by year"""
    if df_model.empty:
        return None
        
    # Get player data
    player_tactic_data = df_model[df_model['Player_ID'] == player_id]
    
    # Filter by year if specified
    if year:
        player_tactic_data = player_tactic_data[player_tactic_data['Year'] == year]
    
    # Check if player_tactic_data is empty
    if len(player_tactic_data) == 0:
        return None
    
    # Define the feature columns that the model expects
    feature_columns = ['Start_encoded', 'CrdY_flag', 'CrdR_flag', 'Outcome_encoded', 
                      'Venue_Away', 'Venue_Home', 'PK_bin', 'PKatt_bin', 'Passing', 
                      'Shooting', 'Creativity', 'Dribbling', 'Defense', 'Impact_Score', 
                      'Year_Encoded', 'Pos_Attacking Mid', 'Pos_Central Mid', 
                      'Pos_Centre Back', 'Pos_Defensive Mid', 'Pos_Forward', 
                      'Pos_Left Back', 'Pos_Left Winger', 'Pos_Right Back']
    
    # Calculate mean values for all features
    try:
        features_series = player_tactic_data[feature_columns].mean()
        
        # Convert to numpy array
        # Check if features_series is a pandas Series
        if isinstance(features_series, pd.Series):
            features_array = features_series.values.astype(float)
        else:
            # Handle scalar values (int, float, etc.)
            features_array = np.array([float(features_series)], dtype=float)
        return features_array.reshape(1, -1)
    except Exception as e:
        print(f"Error converting features: {e}")
        return None

def get_player_scores(player_id, year=None):
    """Get player scores for a specific year or all years if year is None"""
    if df_model.empty:
        return None
        
    player_data_filtered = df_model[df_model['Player_ID'] == player_id]
    
    # Filter by year if specified
    if year:
        player_data_filtered = player_data_filtered[player_data_filtered['Year'] == year]
    
    if len(player_data_filtered) == 0:
        return None
    
    # Calculate mean scores for the abilities (correct mapping)
    try:
        scores = {
            'Passing': float(player_data_filtered['Passing'].mean()),
            'Shooting': float(player_data_filtered['Shooting'].mean()),
            'Creativity': float(player_data_filtered['Creativity'].mean()),
            'Dribbling': float(player_data_filtered['Dribbling'].mean()),
            'Defense': float(player_data_filtered['Defense'].mean())
        }
        return scores
    except Exception as e:
        print(f"Error calculating player scores: {e}")
        return None

def get_aggregated_player_data(player_id):
    """Get aggregated player data across all years"""
    if df_model.empty:
        return None
        
    # Get all data for the player across all years
    player_data_all_years = df_model[df_model['Player_ID'] == player_id]
    
    if len(player_data_all_years) == 0:
        return None
    
    # Calculate aggregated values (mean across all years)
    try:
        aggregated_data = {
            'Passing': float(player_data_all_years['Passing'].mean()),
            'Shooting': float(player_data_all_years['Shooting'].mean()),
            'Creativity': float(player_data_all_years['Creativity'].mean()),
            'Dribbling': float(player_data_all_years['Dribbling'].mean()),
            'Defense': float(player_data_all_years['Defense'].mean()),
            'Impact_Score': float(player_data_all_years['Impact_Score'].mean()),
            'Best_Tactic': 'Unknown'  # Initialize as string
        }
        
        # Handle Best_Tactic separately
        try:
            # Get the most common Best_Tactic value
            if 'Best_Tactic' in player_data_all_years.columns:
                best_tactic_counts = player_data_all_years['Best_Tactic'].value_counts()
                if len(best_tactic_counts) > 0:
                    aggregated_data['Best_Tactic'] = str(best_tactic_counts.index[0])
                else:
                    aggregated_data['Best_Tactic'] = "Unknown"
            else:
                aggregated_data['Best_Tactic'] = "Unknown"
        except:
            aggregated_data['Best_Tactic'] = "Unknown"
        
        return aggregated_data
    except Exception as e:
        print(f"Error aggregating player data: {e}")
        return None

def get_player_manager_periods(player_id):
    """Get manager periods for a player based on date and manager data"""
    if df_model.empty or manager_data.empty:
        return []
    
    try:
        # Get player data with dates
        player_data_all = df_model[df_model['Player_ID'] == player_id]
        if len(player_data_all) == 0:
            return []
        
        # Mock manager periods for demonstration
        # In a real application, this would be based on actual manager assignment data
        periods = []
        
        # Get unique years where player has data
        if 'Year' in player_data_all.columns:
            unique_years = sorted(player_data_all['Year'].unique())
        else:
            unique_years = []
        
        for i, year in enumerate(unique_years):
            # Assign different managers for different years
            manager_ids = ['M01', 'M02', 'M03', 'M04', 'M05']
            manager_id = manager_ids[i % len(manager_ids)]
            
            # Get manager name
            manager_name = f"Manager {manager_id}"
            if not manager_data.empty:
                manager_matches = manager_data[manager_data['Manager_ID'] == manager_id]
                if len(manager_matches) > 0:
                    manager_name = str(manager_matches.iloc[0].get('Manager_Name', f"Manager {manager_id}"))
            
            periods.append({
                'manager_id': manager_id,
                'manager_name': manager_name,
                'start_year': year,
                'end_year': year,
                'color': f"hsl({(i * 60) % 360}, 70%, 50%)"  # Dynamic color assignment
            })
        
        return periods
    except Exception as e:
        print(f"Error getting manager periods: {e}")
        return []

def get_manager_comparison_data(player_id):
    """Get manager comparison data for a player - only include managers who actually managed the player"""
    if df_model.empty:
        return []
    
    try:
        player_data_all = df_model[df_model['Player_ID'] == player_id]
        if len(player_data_all) == 0:
            return []
        
        # Get unique managers who actually managed this player
        if 'Manager_ID' in player_data_all.columns:
            actual_managers = player_data_all['Manager_ID'].unique()
        else:
            actual_managers = []
        
        print(f"[get_manager_comparison_data] Found {len(actual_managers)} managers for player {player_id}: {actual_managers}")
        
        manager_comparison = []
        colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
        
        for i, manager_id in enumerate(actual_managers):
            if pd.isna(manager_id) or str(manager_id) == 'M21':  # Skip NaN managers and M21 (Others)
                continue
                
            # Get data for this manager and player combination
            manager_player_data = player_data_all[player_data_all['Manager_ID'] == manager_id]
            
            if len(manager_player_data) > 0:
                avg_impact = float(manager_player_data['Impact_Score'].mean())
                
                # Get manager name from manager_data if available
                manager_name = str(manager_id)
                if not manager_data.empty:
                    manager_matches = manager_data[manager_data['Manager_ID'] == manager_id]
                    if len(manager_matches) > 0:
                        manager_name = str(manager_matches.iloc[0].get('Manager_Name', manager_id))
                
                manager_comparison.append({
                    'manager_id': str(manager_id),
                    'manager_name': manager_name,
                    'avg_impact_score': round(avg_impact, 2),
                    'color': colors[i % len(colors)],
                    'games_managed': len(manager_player_data)
                })
        
        # Sort by average impact score descending
        manager_comparison.sort(key=lambda x: x['avg_impact_score'], reverse=True)
        print(f"[get_manager_comparison_data] Generated comparison for {len(manager_comparison)} managers")
        return manager_comparison
        
    except Exception as e:
        print(f"Error getting manager comparison data: {e}")
        return []

def get_seasonal_performance_data(player_id):
    """Get seasonal performance data for a player - aggregated impact score and abilities per year"""
    if df_model.empty:
        return []
    
    try:
        player_data_all = df_model[df_model['Player_ID'] == player_id]
        if len(player_data_all) == 0:
            return []
        
        # Get years where player has data
        if 'Year' in player_data_all.columns:
            years = sorted(player_data_all['Year'].unique())
        else:
            years = []
        
        print(f"[get_seasonal_performance_data] Found data for years: {years}")
        
        # Calculate impact score trend over years
        impact_trend = []
        if 'Impact_Score' in player_data_all.columns:
            yearly_impact = player_data_all.groupby('Year')['Impact_Score'].mean().reset_index()
            
            for year in years:
                year_data = yearly_impact[yearly_impact['Year'] == year]
                if len(year_data) > 0:
                    impact_score = float(year_data['Impact_Score'].iloc[0])
                    impact_trend.append({
                        'year': int(year),
                        'impact_score': round(impact_score, 2)
                    })
        
        # Also calculate abilities trend (5 core abilities) - correct mapping
        abilities = ['Passing', 'Shooting', 'Creativity', 'Dribbling', 'Defense']
        ability_mapping = {
            'Passing': 'Passing',
            'Shooting': 'Shooting',
            'Creativity': 'Creativity',
            'Dribbling': 'Dribbling',
            'Defense': 'Defense'
        }
        
        abilities_trend = []
        for ability in abilities:
            data_column = ability_mapping[ability]
            if data_column in player_data_all.columns:
                yearly_values = player_data_all.groupby('Year')[data_column].mean().reset_index()
                
                ability_data = []
                for year in years:
                    year_data = yearly_values[yearly_values['Year'] == year]
                    if len(year_data) > 0:
                        value = float(year_data[data_column].iloc[0])
                        ability_data.append({
                            'year': int(year),
                            'value': round(value, 2)
                        })
                
                if ability_data:  # Only add if we have data
                    abilities_trend.append({
                        'ability': ability,
                        'data': ability_data
                    })
        
        result = {
            'impact_trend': impact_trend,
            'abilities_trend': abilities_trend,
            'years': [int(y) for y in years]
        }
        
        print(f"[get_seasonal_performance_data] Generated trend data for {len(years)} years")
        return result
        
    except Exception as e:
        print(f"Error getting seasonal performance data: {e}")
        return []

def get_tactic_frequency_data(player_id):
    """Get best tactic frequency data for a player"""
    if df_model.empty:
        return []
    
    try:
        player_data_all = df_model[df_model['Player_ID'] == player_id]
        if len(player_data_all) == 0:
            return []
        
        # Count frequency of each best tactic
        frequency_data = []
        if 'Best_Tactic' in player_data_all.columns:
            tactic_counts = player_data_all['Best_Tactic'].value_counts()
            
            colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#FF6384']
            
            for i, (tactic, count) in enumerate(tactic_counts.items()):
                frequency_data.append({
                    'tactic': str(tactic),
                    'count': int(count),
                    'percentage': round((count / len(player_data_all)) * 100, 1),
                    'color': colors[i % len(colors)]
                })
        
        return frequency_data
    except Exception as e:
        print(f"Error getting tactic frequency data: {e}")
        return []

def get_impact_score_over_time(player_id):
    """Get impact score data over time for a player with actual manager information"""
    if df_model.empty:
        return []
        
    # Get all data for the player
    player_data_all = df_model[df_model['Player_ID'] == player_id]
    
    if len(player_data_all) == 0:
        return []
    
    try:
        # Group by month/year and calculate mean impact score with manager info
        monthly_data = defaultdict(list)
        
        # Extract dates, impact scores, and manager IDs
        for _, row in player_data_all.iterrows():
            try:
                date_str = str(row['Date'])
                impact_score = float(row['Impact_Score'])
                manager_id = str(row.get('Manager_ID', 'Unknown'))
                
                # Parse date string to extract month and year
                date_obj = None
                for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%Y-%m-%d %H:%M:%S']:
                    try:
                        date_obj = datetime.datetime.strptime(date_str, fmt)
                        break
                    except ValueError:
                        continue
                
                if date_obj:
                    # Format as "Month Year" (e.g., "Jan 2022")
                    month_year = date_obj.strftime('%b %Y')
                    monthly_data[month_year].append({
                        'impact_score': impact_score,
                        'manager_id': manager_id
                    })
            except Exception as e:
                print(f"Error processing row for impact over time: {e}")
                continue
        
        # Calculate mean for each month with manager info
        result = []
        for month_year, data_points in monthly_data.items():
            if data_points:
                mean_score = sum(d['impact_score'] for d in data_points) / len(data_points)
                # Use the most common manager for this month
                manager_counts = defaultdict(int)
                for d in data_points:
                    manager_counts[d['manager_id']] += 1
                most_common_manager = max(manager_counts.items(), key=lambda x: x[1])[0]
                
                result.append({
                    'date': month_year,
                    'impact_score': round(float(mean_score), 2),
                    'manager_id': most_common_manager
                })
        
        # Sort chronologically by date
        def date_key(item):
            try:
                parts = item['date'].split(' ')
                if len(parts) == 2:
                    month_abbr, year = parts
                    # Handle case where month_abbr might not be found
                    try:
                        month_num = list(calendar.month_abbr).index(month_abbr)
                    except ValueError:
                        month_num = 1  # Default to January if not found
                    return (int(year), month_num)
                else:
                    return (0, 0)
            except:
                return (0, 0)
        
        result.sort(key=date_key)
        print(f"[get_impact_score_over_time] Generated {len(result)} data points for player {player_id}")
        return result
    except Exception as e:
        print(f"Error getting impact score over time: {e}")
        return []

def get_tactical_recommendations(player_id, model_name='XGBoost', year=None):
    """Get tactical recommendations for a player using the specified model"""
    if df_model.empty:
        return []
        
    # Get player data
    player_data_filtered = df_model[df_model['Player_ID'] == player_id]
    
    # Filter by year if specified
    if year:
        player_data_filtered = player_data_filtered[player_data_filtered['Year'] == year]
    
    # If we still don't have data, return empty recommendations
    if len(player_data_filtered) == 0:
        return []
    
    # Try to load the model
    model = load_model(model_name)
    
    # If model loaded successfully, use it for predictions
    if model is not None:
        try:
            # Get features for the player
            features = get_player_features(player_id, year)
            
            if features is not None:
                # Get predictions from the model
                predictions = model.predict(features)
                
                # Get the tactic component column names
                tactic_columns = [col for col in df_model.columns if col.startswith('Tactic_Component_')]
                
                # Create recommendations based on model predictions
                recommendations = []
                
                # Handle different prediction formats
                if hasattr(predictions, 'shape') and len(predictions.shape) > 1:
                    # Multi-dimensional array
                    pred_values = predictions[0] if len(predictions) > 0 else []
                elif hasattr(predictions, '__len__'):
                    # 1D array or list
                    pred_values = predictions
                else:
                    # Single value
                    pred_values = [predictions]
                
                # Ensure we have enough values for all tactic components
                num_components = len(tactic_columns)
                if len(pred_values) < num_components:
                    # Pad with average values from the data
                    avg_values = [player_data_filtered[col].mean() for col in tactic_columns]
                    pred_values = list(pred_values) + avg_values[len(pred_values):]
                
                for i, component in enumerate(tactic_columns):
                    if i < len(pred_values):
                        value = float(pred_values[i])
                    else:
                        # Fallback to data mean
                        value = float(player_data_filtered[component].mean()) if len(player_data_filtered) > 0 else 1.0
                    
                    recommendations.append({
                        'component': component,
                        'value': value,
                        'impact': value
                    })
                
                return recommendations
        except Exception as e:
            print(f"Error using model {model_name}: {e}")
    
    # Fallback to stored best_tactic if model fails or is not available
    try:
        best_tactic = "Tactic_Component_1"  # Default fallback
        if len(player_data_filtered) > 0:
            # Get the most common Best_Tactic value
            best_tactic_counts = player_data_filtered['Best_Tactic'].value_counts()
            if not best_tactic_counts.empty:
                best_tactic = str(best_tactic_counts.index[0])
    except:
        best_tactic = "Tactic_Component_1"  # Default fallback
    
    tactic_columns = [col for col in df_model.columns if col.startswith('Tactic_Component_')]
    
    recommendations = []
    for component in tactic_columns:
        # For the best tactic, use the actual value from the data
        # For others, use a lower value
        try:
            if component == best_tactic:
                # Get the actual value for the best tactic from the data
                value = float(player_data_filtered[component].mean())
            else:
                # Use a lower value for non-best tactics
                value = float(player_data_filtered[component].mean()) * 0.7  # Reduced value
        except:
            value = 0.5 if component == best_tactic else 0.3
        
        recommendations.append({
            'component': component,
            'value': value,
            'impact': value
        })
    
    return recommendations

def get_manager_summary():
    """Generate manager-level tactic usage summary"""
    summary = {}
    
    for manager_id, tactics in manager_tactics.items():
        # Skip manager M21 as per requirements
        if manager_id == "M21":
            continue
            
        summary[manager_id] = {
            'tactics': tactics,
            'main_tactic': max(tactics, key=lambda x: x['count']) if tactics else None
        }
    
    return summary

def save_manager_summary():
    """Save manager summary to JSON file"""
    try:
        summary = get_manager_summary()
        with open('manager_tactic_summary.json', 'w') as f:
            json.dump(summary, f, indent=2)
        return summary
    except Exception as e:
        print(f"Error saving manager summary: {e}")
        return {}

def get_manager_formations():
    """Get manager formations from the manager_formation.xlsx file"""
    try:
        formations = {}
        if not manager_formation_data.empty:
            for _, row in manager_formation_data.iterrows():
                manager_id = str(row['Manager_ID'])
                formation = str(row['Formation'])
                if manager_id not in formations:
                    formations[manager_id] = []
                formations[manager_id].append(formation)
        return formations
    except Exception as e:
        print(f"Error loading manager formations: {e}")
        return {}

@app.route('/get_tactical_components')
def get_tactical_components():
    """API endpoint to get tactical components with robust error handling"""
    try:
        player_id = request.args.get('player_id')
        year = request.args.get('year')
        model_name = request.args.get('model', 'XGBoost')
        
        print(f"[get_tactical_components] Request: player_id={player_id}, year={year}, model={model_name}")
        
        if not player_id:
            error_msg = "Player ID is required"
            print(f"[get_tactical_components] ERROR: {error_msg}")
            return jsonify(get_safe_response(player_id, year, model_name, error_msg)), 400
        
        # Convert year to int if provided
        year_int = None
        if year and str(year).strip() and str(year).lower() not in ['all', 'all years']:
            try:
                year_int = int(year)
            except ValueError:
                error_msg = f"Invalid year format: {year}"
                print(f"[get_tactical_components] ERROR: {error_msg}")
                return jsonify(get_safe_response(player_id, year, model_name, error_msg)), 400
        
        # Check if data files are loaded
        if df_model.empty:
            error_msg = "Model data not available - df_model.csv not loaded"
            print(f"[get_tactical_components] ERROR: {error_msg}")
            return jsonify(get_safe_response(player_id, year, model_name, error_msg)), 500
        
        # Use the shared function for consistency
        shared_result = get_shared_tactical_recommendations(player_id, model_name, year)
        
        if 'error' in shared_result:
            print(f"[get_tactical_components] ERROR from shared function: {shared_result['error']}")
            return jsonify(get_safe_response(player_id, year, model_name, shared_result['error'])), 400
        
        # Extract data from shared result
        recommendations = shared_result['recommendations']
        best_tactic_data = shared_result['best_tactic_data']
        
        if not recommendations:
            print(f"[get_tactical_components] ERROR: No valid tactical components calculated")
            return jsonify(get_safe_response(player_id, year, model_name, "No valid tactical components could be calculated"))
        
        # Find best component
        best_component = max(recommendations, key=lambda x: x['value'])
        best_tactic = {
            "name": format_tactic_component_name(best_component['component']),
            "component": best_component['component'],
            "score": best_component['value'],
            "value": best_component['value'],
            "formation": get_formation_for_component(best_component['component']),
            "description": get_tactic_description(best_component['component']),
            "descriptors": get_tactic_descriptors(best_component['component'])
        }
        
        print(f"[get_tactical_components] Best tactic identified: {best_tactic['name']} with score {best_tactic['score']:.2f}")
        print(f"[get_tactical_components] Descriptors count: {len(best_tactic['descriptors'])}")
        
        # Get top 6 managers with relevance scoring (with safe fallback)
        try:
            top_managers = get_top_managers_for_player(player_id, year_int, model_name, num_managers=6)
        except Exception as e:
            print(f"[get_tactical_components] Error getting managers: {e}")
            top_managers = []
        
        # Format managers for consistent output
        best_managers = []
        for manager in top_managers[:5]:  # Ensure top 5 only
            try:
                best_managers.append({
                    "manager_name": manager.get('manager_name', 'Unknown Manager'),
                    "manager_id": manager.get('manager_id', 'Unknown'),
                    "score": round(float(manager.get('score', 0)), 3),
                    "formations": manager.get('formations', [])
                })
            except Exception as e:
                print(f"[get_tactical_components] Error formatting manager: {e}")
                continue
        
        # Sort components by value for better display
        components_data = sorted(recommendations, key=lambda x: x['value'], reverse=True)
        
        # Create component scores dictionary
        component_scores = {item['component']: item['value'] for item in components_data}
        
        # Generate detailed analysis
        player_name = get_player_name(player_id)
        detailed_analysis = {
            "summary": f"Player {player_name} excels in {format_tactic_component_name(best_component['component'])} with a score of {best_component['value']:.2f}. This suggests optimal performance in {get_formation_for_component(best_component['component'])} formation.",
            "notes": f"Best tactical approach: {format_tactic_component_name(best_component['component'])} ({best_component['value']:.2f}). Top recommended managers: {', '.join([m['manager_name'] for m in best_managers[:3]])}." if best_managers else f"Best tactical approach: {format_tactic_component_name(best_component['component'])} ({best_component['value']:.2f}). No manager recommendations available.",
            "total_components": len(components_data),
            "year_analyzed": year or "All Years",
            "model_used": model_name
        }
        
        response_data = {
            "player_id": player_id,
            "player_name": player_name,
            "year": year or "All Years",
            "model": model_name,
            "best_tactic": best_tactic,
            "best_component": best_tactic,  # For compatibility
            "best_managers": best_managers,
            "top_managers": best_managers,  # For compatibility
            "components_data": components_data,
            "component_scores": component_scores,
            "detailed_analysis": detailed_analysis,
            "total_components": len(components_data)
        }
        
        print(f"[get_tactical_components] SUCCESS: Returning data with {len(best_managers)} managers and {len(components_data)} components")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = f"Internal server error: {str(e)}"
        print(f"[get_tactical_components] EXCEPTION: {error_msg}")
        import traceback
        traceback.print_exc()
        # ALWAYS return safe JSON, never an error response
        return jsonify(get_safe_response(
            player_id=request.args.get('player_id') if request else None,
            year=request.args.get('year') if request else None,
            model_name=request.args.get('model', 'XGBoost') if request else 'XGBoost',
            error_message=f"System error occurred while loading tactical data: {str(e)}"))

def get_top_managers_for_player(player_id, year=None, model_name='XGBoost', num_managers=5):
    """Get top N managers for a player based on tactical component matching"""
    try:
        print(f"Getting top {num_managers} managers for player {player_id}, year {year}")
        
        # Get player's tactical profile
        player_data = df_model[df_model['Player_ID'] == player_id]
        
        if year:
            player_data = player_data[player_data['Year'] == year]
        
        if len(player_data) == 0:
            print(f"No data found for player {player_id}")
            return []
        
        # Get tactical component columns
        tactic_columns = [col for col in df_model.columns if col.startswith('Tactic_Component_')]
        
        if not tactic_columns:
            print("No tactical component columns found")
            return []
        
        # Calculate player's average tactical profile
        player_profile = {}
        for col in tactic_columns:
            try:
                player_profile[col] = float(player_data[col].mean())
            except:
                player_profile[col] = 0.0
        
        print(f"Player tactical profile: {player_profile}")
        
        # Get manager data and formations
        manager_formations = get_manager_formations()
        
        # Calculate manager profiles and similarity scores
        manager_scores = []
        
        # Get unique managers from the data
        all_managers = df_model['Manager_ID'].dropna().unique()
        
        for manager_id in all_managers:
            if str(manager_id) == 'M21':  # Skip M21 (Others) as per requirements
                continue
                
            try:
                # Get manager's tactical profile from the data
                manager_data = df_model[df_model['Manager_ID'] == manager_id]
                
                if len(manager_data) == 0:
                    continue
                
                # Calculate manager's average tactical profile
                manager_profile = {}
                for col in tactic_columns:
                    try:
                        manager_profile[col] = float(manager_data[col].mean())
                    except:
                        manager_profile[col] = 0.0
                
                # Calculate cosine similarity
                similarity_score = calculate_cosine_similarity(player_profile, manager_profile, tactic_columns)
                
                # Get manager name
                manager_name = get_manager_name(manager_id)
                
                # Get manager formations
                formations = manager_formations.get(str(manager_id), [])
                
                manager_scores.append({
                    'manager_id': str(manager_id),
                    'manager_name': manager_name,
                    'score': similarity_score,
                    'formations': formations
                })
                
            except Exception as e:
                print(f"Error processing manager {manager_id}: {e}")
                continue
        
        # Sort by score (highest first) and take top N
        manager_scores.sort(key=lambda x: x['score'], reverse=True)
        top_managers = manager_scores[:num_managers]
        
        print(f"Found {len(top_managers)} top managers")
        for manager in top_managers:
            print(f"  {manager['manager_name']}: {manager['score']:.3f}")
        
        return top_managers
        
    except Exception as e:
        print(f"Error getting top managers: {e}")
        import traceback
        traceback.print_exc()
        return []

def calculate_cosine_similarity(profile1, profile2, feature_columns):
    """Calculate cosine similarity between two tactical profiles"""
    try:
        import math
        
        # Get vectors
        vec1 = [profile1.get(col, 0.0) for col in feature_columns]
        vec2 = [profile2.get(col, 0.0) for col in feature_columns]
        
        # Calculate dot product
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        
        # Calculate magnitudes
        magnitude1 = math.sqrt(sum(a * a for a in vec1))
        magnitude2 = math.sqrt(sum(a * a for a in vec2))
        
        # Avoid division by zero
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        # Calculate cosine similarity
        similarity = dot_product / (magnitude1 * magnitude2)
        
        # Normalize to [0, 1] range
        normalized_similarity = (similarity + 1) / 2
        
        return round(normalized_similarity, 3)
        
    except Exception as e:
        print(f"Error calculating cosine similarity: {e}")
        return 0.0

def get_manager_name(manager_id):
    """Get manager name from manager ID"""
    try:
        # Look up in manager data if available
        if not manager_data.empty:
            manager_row = manager_data[manager_data['Manager_ID'] == manager_id]
            if not manager_row.empty:
                return str(manager_row.iloc[0]['Manager_Name'])
        
        # Fallback to generic name
        return f"Manager {manager_id}"
        
    except Exception as e:
        print(f"Error getting manager name for {manager_id}: {e}")
        return f"Manager {manager_id}"

def get_formation_for_component(component):
    """Get formation for tactical component"""
    formations = {
        'Tactic_Component_1': '4-2-3-1 Defensive',
        'Tactic_Component_2': '4-3-3 Possession',
        'Tactic_Component_3': '3-5-2 Attacking',
        'Tactic_Component_4': '4-4-2 High Press',
        'Tactic_Component_5': '4-2-2-2 Counter',
        'Tactic_Component_6': '3-4-3 Wide Play',
        'Tactic_Component_7': '4-1-4-1 Technical'
    }
    return formations.get(component, 'Formation N/A')

def get_tactic_variable_loadings(component):
    """Get top 10 variable loadings for a tactical component"""
    # This would typically come from your PCA/factor analysis results
    # For demonstration, I'm providing sample loadings based on football tactics
    variable_loadings = {
        'Tactic_Component_1': [
            {'variable': 'Line_Height__Low', 'loading': 2.03},
            {'variable': 'Defensive_Style__Low Block', 'loading': 1.91},
            {'variable': 'Build_Up__Direct', 'loading': 1.77},
            {'variable': 'Pressing__Low', 'loading': 1.65},
            {'variable': 'Width__Narrow', 'loading': 1.54},
            {'variable': 'Tempo__Slow', 'loading': 1.43},
            {'variable': 'Risk__Conservative', 'loading': 1.32},
            {'variable': 'Attacking_Style__Counter', 'loading': 1.28},
            {'variable': 'Defensive_Line__Deep', 'loading': 1.15},
            {'variable': 'Mentality__Defensive', 'loading': 1.08}
        ],
        'Tactic_Component_2': [
            {'variable': 'Possession__High', 'loading': 2.15},
            {'variable': 'Passing__Short', 'loading': 2.08},
            {'variable': 'Build_Up__Patient', 'loading': 1.94},
            {'variable': 'Tempo__Controlled', 'loading': 1.82},
            {'variable': 'Width__Wide', 'loading': 1.71},
            {'variable': 'Risk__Balanced', 'loading': 1.58},
            {'variable': 'Pressing__Medium', 'loading': 1.45},
            {'variable': 'Line_Height__Medium', 'loading': 1.33},
            {'variable': 'Attacking_Style__Possession', 'loading': 1.26},
            {'variable': 'Mentality__Balanced', 'loading': 1.12}
        ],
        'Tactic_Component_3': [
            {'variable': 'Attacking_Style__Aggressive', 'loading': 2.32},
            {'variable': 'Line_Height__High', 'loading': 2.18},
            {'variable': 'Tempo__Fast', 'loading': 2.05},
            {'variable': 'Risk__Attacking', 'loading': 1.93},
            {'variable': 'Pressing__High', 'loading': 1.81},
            {'variable': 'Width__Wide', 'loading': 1.67},
            {'variable': 'Build_Up__Quick', 'loading': 1.54},
            {'variable': 'Mentality__Attacking', 'loading': 1.42},
            {'variable': 'Defensive_Style__High Line', 'loading': 1.31},
            {'variable': 'Creative_Freedom__High', 'loading': 1.19}
        ],
        'Tactic_Component_4': [
            {'variable': 'Pressing__Very High', 'loading': 2.44},
            {'variable': 'Line_Height__Very High', 'loading': 2.21},
            {'variable': 'Tempo__Very Fast', 'loading': 2.08},
            {'variable': 'Aggressive_Pressing__Enabled', 'loading': 1.96},
            {'variable': 'Counter_Pressing__High', 'loading': 1.84},
            {'variable': 'Risk__High', 'loading': 1.72},
            {'variable': 'Intensity__Maximum', 'loading': 1.61},
            {'variable': 'Defensive_Line__High', 'loading': 1.48},
            {'variable': 'Attacking_Style__High Press', 'loading': 1.35},
            {'variable': 'Mentality__Very Attacking', 'loading': 1.23}
        ],
        'Tactic_Component_5': [
            {'variable': 'Direct_Passing__High', 'loading': 2.27},
            {'variable': 'Counter_Attack__Enabled', 'loading': 2.14},
            {'variable': 'Tempo__Variable', 'loading': 1.98},
            {'variable': 'Long_Ball__Frequent', 'loading': 1.85},
            {'variable': 'Vertical_Play__High', 'loading': 1.73},
            {'variable': 'Risk__Counter', 'loading': 1.61},
            {'variable': 'Transition__Fast', 'loading': 1.49},
            {'variable': 'Attacking_Style__Direct', 'loading': 1.37},
            {'variable': 'Width__Variable', 'loading': 1.24},
            {'variable': 'Mentality__Counter', 'loading': 1.12}
        ],
        'Tactic_Component_6': [
            {'variable': 'Wing_Play__High', 'loading': 2.51},
            {'variable': 'Cross_Frequency__High', 'loading': 2.38},
            {'variable': 'Width__Very Wide', 'loading': 2.16},
            {'variable': 'Flank_Utilization__Maximum', 'loading': 2.04},
            {'variable': 'Wing_Back_Attack__High', 'loading': 1.89},
            {'variable': 'Overlap__Frequent', 'loading': 1.77},
            {'variable': 'Aerial_Threat__High', 'loading': 1.65},
            {'variable': 'Attacking_Width__Maximum', 'loading': 1.52},
            {'variable': 'Cross_Type__Mixed', 'loading': 1.39},
            {'variable': 'Mentality__Wing Focus', 'loading': 1.27}
        ],
        'Tactic_Component_7': [
            {'variable': 'Creative_Freedom__Very High', 'loading': 2.33},
            {'variable': 'Technical_Play__High', 'loading': 2.19},
            {'variable': 'Pass_Complexity__High', 'loading': 2.06},
            {'variable': 'Skill_Usage__High', 'loading': 1.94},
            {'variable': 'Individual_Brilliance__Enabled', 'loading': 1.81},
            {'variable': 'Tempo__Technical', 'loading': 1.68},
            {'variable': 'Risk__Creative', 'loading': 1.55},
            {'variable': 'Dribbling__Frequent', 'loading': 1.43},
            {'variable': 'Passing_Style__Intricate', 'loading': 1.31},
            {'variable': 'Mentality__Expressive', 'loading': 1.18}
        ]
    }
    
    return variable_loadings.get(component, [])

def get_tactic_description(component):
    """Get description for tactical component"""
    descriptions = {
        'Tactic_Component_1': 'Defensive stability and compactness - Focus on maintaining defensive shape',
        'Tactic_Component_2': 'Possession-based play and build-up - Emphasize ball retention and controlled attacking',
        'Tactic_Component_3': 'Progressive attacking and transitions - Quick transitions from defense to attack',
        'Tactic_Component_4': 'High-intensity pressing and aggression - Aggressive pressing to win back possession',
        'Tactic_Component_5': 'Direct attacking and fast breaks - Direct passes and quick counter-attacks',
        'Tactic_Component_6': 'Wing play and crossing opportunities - Utilize flanks and deliver crosses',
        'Tactic_Component_7': 'Technical play and creative passing - Intricate passing patterns and creative solutions'
    }
    return descriptions.get(component, 'Tactical approach')

def get_tactic_descriptors(component):
    """Get top 10 descriptors/features for a tactical component"""
    descriptors = {
        'Tactic_Component_1': [
            'Defensive stability', 'Compact defensive shape', 'Low defensive line',
            'Disciplined positioning', 'Counter-attacking focus', 'Solid defensive block',
            'Organized defending', 'Deep defending', 'Defensive solidity', 'Structured play'
        ],
        'Tactic_Component_2': [
            'Possession-based play', 'Ball retention', 'Short passing', 'Build-up play',
            'Patient approach', 'Controlled tempo', 'Passing accuracy', 'Territory control',
            'Tactical patience', 'Progressive passing'
        ],
        'Tactic_Component_3': [
            'Progressive attacking', 'Quick transitions', 'Vertical play', 'Forward momentum',
            'Attacking thrust', 'Direct attacking', 'Fast build-up', 'Transition speed',
            'Attacking intensity', 'Forward passes'
        ],
        'Tactic_Component_4': [
            'High pressing', 'Aggressive pressing', 'High defensive line', 'Intense pressing',
            'Ball recovery', 'Pressing triggers', 'High tempo', 'Coordinated pressing',
            'Defensive aggression', 'High energy'
        ],
        'Tactic_Component_5': [
            'Direct attacking', 'Fast breaks', 'Counter-attacks', 'Quick transitions',
            'Vertical passes', 'Pace in attack', 'Direct play', 'Speed of attack',
            'Fast counter', 'Rapid transitions'
        ],
        'Tactic_Component_6': [
            'Wing play', 'Crossing opportunities', 'Flank utilization', 'Wide attacks',
            'Cross delivery', 'Wing-based attacks', 'Wide positioning', 'Flank dominance',
            'Aerial threat', 'Width in attack'
        ],
        'Tactic_Component_7': [
            'Technical play', 'Creative passing', 'Intricate patterns', 'Skillful play',
            'Creative solutions', 'Technical ability', 'Passing creativity', 'Tactical intelligence',
            'Creative freedom', 'Expressive play'
        ]
    }
    return descriptors.get(component, ['Tactical approach', 'Strategic play', 'Team coordination'])

def get_player_name(player_id):
    """Get player name from player ID"""
    try:
        if not player_data.empty:
            player_matches = player_data[player_data['Player_ID'] == player_id]
            if len(player_matches) > 0:
                return str(player_matches.iloc[0].get('Common_Name', f'Player {player_id}'))
    except Exception as e:
        print(f"Error getting player name for {player_id}: {e}")
    return f'Player {player_id}'

def format_tactic_component_name(component):
    """Format tactical component name for display"""
    if not component:
        return 'Unknown Component'
    
    # Remove prefix and format
    name = component.replace('Tactic_Component_', 'Tactical Component ')
    return name

def get_top_players_for_manager(manager_id, model_name='XGBoost', year=None):
    """Get top 6 players best suited for a manager based on tactical component matching"""
    try:
        # Skip M21 manager as per requirements
        if str(manager_id) == 'M21':
            return []
            
        if df_model.empty:
            return []
        
        # Get manager's tactical profile
        manager_tactical_components = manager_tactics.get(manager_id, [])
        if not manager_tactical_components:
            return []
        
        # Get the best tactical component for this manager
        best_manager_component = None
        best_count = 0
        
        for component_info in manager_tactical_components:
            if isinstance(component_info, dict) and 'count' in component_info:
                if component_info['count'] > best_count:
                    best_count = component_info['count']
                    best_manager_component = component_info.get('tactic')
        
        if not best_manager_component:
            return []
        
        # Get all players (excluding those managed by M21)
        all_players = df_model[df_model['Manager_ID'] != 'M21']['Player_ID'].unique()
        
        # Calculate suitability scores for each player
        player_scores = []
        
        for player_id in all_players:
            # Filter data for this player, excluding M21 manager data
            player_data = df_model[(df_model['Player_ID'] == player_id) & (df_model['Manager_ID'] != 'M21')]
            
            # Filter by year if specified
            if year:
                player_data = player_data[player_data['Year'] == int(year)]
            
            if len(player_data) == 0:
                continue
            
            # Get player's tactical component value for the manager's best component
            if best_manager_component in player_data.columns:
                tactical_fit = float(player_data[best_manager_component].mean())
                impact_score = float(player_data['Impact_Score'].mean())
                
                # Get player's best tactical component
                tactic_columns_local = [col for col in df_model.columns if col.startswith('Tactic_Component_')]
                player_best_component_value = 0
                for col in tactic_columns_local:
                    try:
                        col_value = float(player_data[col].mean())
                        if col_value > player_best_component_value:
                            player_best_component_value = col_value
                    except:
                        continue
                
                # New ranking logic:
                # Primary factor: compatibility between player's best tactical component and manager's tactical component
                # Secondary factor (tiebreaker): impact score
                # We use the manager's tactical component value as the primary ranking factor
                # and impact score only as a small tiebreaker (1% weight)
                suitability_score = tactical_fit + (impact_score * 0.01)
                
                player_name = get_player_name(player_id)
                
                # Get player abilities (correct mapping)
                player_abilities = {
                    'Passing': float(player_data['Passing'].mean()),
                    'Shooting': float(player_data['Shooting'].mean()),
                    'Creativity': float(player_data['Creativity'].mean()),
                    'Dribbling': float(player_data['Dribbling'].mean()),
                    'Defense': float(player_data['Defense'].mean())
                }
                
                player_scores.append({
                    'player_id': player_id,
                    'name': player_name,
                    'suitability_score': suitability_score,
                    'impact_score': impact_score,
                    'tactical_fit': tactical_fit,
                    'abilities': player_abilities
                })
        
        # Sort by suitability score and take top 6 (increased from 5)
        player_scores.sort(key=lambda x: x['suitability_score'], reverse=True)
        top_players = player_scores[:6]  # Changed from 5 to 6
        
        return top_players
        
    except Exception as e:
        print(f"Error getting top players for manager {manager_id}: {e}")
        return []

def get_manager_insights(manager_id, year=None):
    """Get additional insights for a manager"""
    try:
        if df_model.empty:
            return {}
        
        # Get manager's data
        manager_data_filtered = df_model[df_model['Manager_ID'] == manager_id]
        
        # Filter by year if specified
        if year:
            manager_data_filtered = manager_data_filtered[manager_data_filtered['Year'] == int(year)]
        
        if len(manager_data_filtered) == 0:
            return {}
        
        # Get best tactical components for this manager
        tactic_columns_local = [col for col in df_model.columns if col.startswith('Tactic_Component_')]
        
        component_scores = []
        for component in tactic_columns_local:
            if component in manager_data_filtered.columns:
                value = float(manager_data_filtered[component].mean())
                component_scores.append({
                    'name': format_tactic_component_name(component),
                    'component': component,
                    'value': value
                })
        
        # Sort by value
        component_scores.sort(key=lambda x: x['value'], reverse=True)
        
        # Get average player attributes (correct mapping)
        average_attributes = {
            'Passing': float(manager_data_filtered['Passing'].mean()),
            'Shooting': float(manager_data_filtered['Shooting'].mean()),
            'Creativity': float(manager_data_filtered['Creativity'].mean()),
            'Dribbling': float(manager_data_filtered['Dribbling'].mean()),
            'Defense': float(manager_data_filtered['Defense'].mean())
        }
        
        # Get seasonal trends (simplified)
        seasonal_trends = []
        if 'Year' in manager_data_filtered.columns:
            yearly_data = manager_data_filtered.groupby('Year').agg({
                'Tactic_Component_1': 'mean',
                'Tactic_Component_2': 'mean',
                'Tactic_Component_3': 'mean',
                'Tactic_Component_4': 'mean',
                'Tactic_Component_5': 'mean',
                'Tactic_Component_6': 'mean',
                'Tactic_Component_7': 'mean'
            }).reset_index()
            
            # For simplicity, we'll use the average of all components as the trend value
            for _, row in yearly_data.iterrows():
                avg_value = (
                    row['Tactic_Component_1'] + row['Tactic_Component_2'] + 
                    row['Tactic_Component_3'] + row['Tactic_Component_4'] + 
                    row['Tactic_Component_5'] + row['Tactic_Component_6'] + 
                    row['Tactic_Component_7']
                ) / 7
                
                seasonal_trends.append({
                    'year': int(row['Year']),
                    'value': float(avg_value)
                })
        
        return {
            'best_components': component_scores[:5],  # Top 5 components
            'average_attributes': average_attributes,
            'seasonal_trends': seasonal_trends
        }
        
    except Exception as e:
        print(f"Error getting manager insights for {manager_id}: {e}")
        return {}

def get_manager_formation_details(manager_id):
    """Get detailed formation information for a manager"""
    try:
        formations = []
        manager_formations = get_manager_formations()
        manager_formation_list = manager_formations.get(manager_id, [])
        
        for formation in manager_formation_list:
            # Get formation details
            formation_details = {
                'name': f"Formation for {get_manager_name(manager_id)}",
                'formation': formation,
                'description': f"Preferred formation: {formation}"
            }
            formations.append(formation_details)
        
        return formations
        
    except Exception as e:
        print(f"Error getting formation details for manager {manager_id}: {e}")
        return []

def get_formation_layout(manager_id):
    """Get formation layout for visualization on football pitch"""
    try:
        # This is a simplified implementation
        # In a real application, this would be based on actual formation data
        
        # Get manager's preferred formations
        manager_formations = get_manager_formations()
        formations = manager_formations.get(manager_id, [])
        
        if not formations:
            return []
        
        # Use the first formation for visualization
        formation = formations[0] if formations else "4-4-2"
        
        # Define positions based on formation (simplified)
        positions = []
        
        # Simplified position layout for common formations
        if formation == "4-4-2":
            positions = [
                {'x': 0.5, 'y': 0.1, 'role': 'goalkeeper', 'number': '1'},
                {'x': 0.2, 'y': 0.3, 'role': 'defender', 'number': '2'},
                {'x': 0.4, 'y': 0.3, 'role': 'defender', 'number': '5'},
                {'x': 0.6, 'y': 0.3, 'role': 'defender', 'number': '6'},
                {'x': 0.8, 'y': 0.3, 'role': 'defender', 'number': '3'},
                {'x': 0.3, 'y': 0.5, 'role': 'midfielder', 'number': '4'},
                {'x': 0.5, 'y': 0.5, 'role': 'midfielder', 'number': '8'},
                {'x': 0.7, 'y': 0.5, 'role': 'midfielder', 'number': '7'},
                {'x': 0.9, 'y': 0.5, 'role': 'midfielder', 'number': '11'},
                {'x': 0.4, 'y': 0.7, 'role': 'forward', 'number': '9'},
                {'x': 0.6, 'y': 0.7, 'role': 'forward', 'number': '10'}
            ]
        elif formation == "4-3-3":
            positions = [
                {'x': 0.5, 'y': 0.1, 'role': 'goalkeeper', 'number': '1'},
                {'x': 0.2, 'y': 0.3, 'role': 'defender', 'number': '2'},
                {'x': 0.4, 'y': 0.3, 'role': 'defender', 'number': '5'},
                {'x': 0.6, 'y': 0.3, 'role': 'defender', 'number': '6'},
                {'x': 0.8, 'y': 0.3, 'role': 'defender', 'number': '3'},
                {'x': 0.3, 'y': 0.5, 'role': 'midfielder', 'number': '4'},
                {'x': 0.5, 'y': 0.5, 'role': 'midfielder', 'number': '8'},
                {'x': 0.7, 'y': 0.5, 'role': 'midfielder', 'number': '7'},
                {'x': 0.2, 'y': 0.7, 'role': 'forward', 'number': '11'},
                {'x': 0.5, 'y': 0.7, 'role': 'forward', 'number': '9'},
                {'x': 0.8, 'y': 0.7, 'role': 'forward', 'number': '10'}
            ]
        elif formation == "3-5-2":
            positions = [
                {'x': 0.5, 'y': 0.1, 'role': 'goalkeeper', 'number': '1'},
                {'x': 0.3, 'y': 0.3, 'role': 'defender', 'number': '5'},
                {'x': 0.5, 'y': 0.3, 'role': 'defender', 'number': '6'},
                {'x': 0.7, 'y': 0.3, 'role': 'defender', 'number': '3'},
                {'x': 0.2, 'y': 0.5, 'role': 'midfielder', 'number': '2'},
                {'x': 0.4, 'y': 0.5, 'role': 'midfielder', 'number': '4'},
                {'x': 0.6, 'y': 0.5, 'role': 'midfielder', 'number': '8'},
                {'x': 0.8, 'y': 0.5, 'role': 'midfielder', 'number': '7'},
                {'x': 0.5, 'y': 0.5, 'role': 'midfielder', 'number': '10'},
                {'x': 0.4, 'y': 0.7, 'role': 'forward', 'number': '9'},
                {'x': 0.6, 'y': 0.7, 'role': 'forward', 'number': '11'}
            ]
        else:
            # Default 4-4-2 formation
            positions = [
                {'x': 0.5, 'y': 0.1, 'role': 'goalkeeper', 'number': '1'},
                {'x': 0.2, 'y': 0.3, 'role': 'defender', 'number': '2'},
                {'x': 0.4, 'y': 0.3, 'role': 'defender', 'number': '5'},
                {'x': 0.6, 'y': 0.3, 'role': 'defender', 'number': '6'},
                {'x': 0.8, 'y': 0.3, 'role': 'defender', 'number': '3'},
                {'x': 0.3, 'y': 0.5, 'role': 'midfielder', 'number': '4'},
                {'x': 0.5, 'y': 0.5, 'role': 'midfielder', 'number': '8'},
                {'x': 0.7, 'y': 0.5, 'role': 'midfielder', 'number': '7'},
                {'x': 0.9, 'y': 0.5, 'role': 'midfielder', 'number': '11'},
                {'x': 0.4, 'y': 0.7, 'role': 'forward', 'number': '9'},
                {'x': 0.6, 'y': 0.7, 'role': 'forward', 'number': '10'}
            ]
        
        return positions
        
    except Exception as e:
        print(f"Error getting formation layout for manager {manager_id}: {e}")
        return []
@app.route('/')
def index():
    """Main dashboard page"""
    print("[/] Main dashboard route hit")
    # Convert DataFrame to list of dictionaries properly
    player_list = []
    if not players_df.empty:
        for _, row in players_df.iterrows():
            player_list.append({
                'Player_ID': row['Player_ID'],
                'Player_Name': row['Player_Name']
            })
    
    # Save manager summary
    manager_summary = save_manager_summary()
    
    return render_template('index.html', 
                         players=player_list,
                         models=list(MODELS.keys()),
                         years=years,
                         manager_summary=manager_summary)

@app.route('/managers')
def managers_page():
    """Managers recommendation page"""
    print("[/managers] Managers page route hit")
    # Convert DataFrame to list of dictionaries properly
    player_list = []
    if not players_df.empty:
        for _, row in players_df.iterrows():
            player_list.append({
                'Player_ID': row['Player_ID'],
                'Player_Name': row['Player_Name']
            })
    
    # Get the player_id from URL parameters if available
    player_id = request.args.get('player_id')
    
    return render_template('managers.html', 
                         players=player_list,
                         models=list(MODELS.keys()),
                         years=years,
                         selected_player_id=player_id)

@app.route('/tactical_components')
def tactical_components_page():
    """Tactical Components Comparison page"""
    # Convert DataFrame to list of dictionaries properly
    player_list = []
    if not players_df.empty:
        for _, row in players_df.iterrows():
            player_list.append({
                'Player_ID': row['Player_ID'],
                'Player_Name': row['Player_Name']
            })
    
    return render_template('tactical_components.html', 
                         players=player_list,
                         models=list(MODELS.keys()),
                         years=years)

@app.route('/manager_analysis')
def manager_analysis_page():
    """Manager Analysis page"""
    # Convert DataFrame to list of dictionaries properly
    player_list = []
    if not players_df.empty:
        for _, row in players_df.iterrows():
            player_list.append({
                'Player_ID': row['Player_ID'],
                'Player_Name': row['Player_Name']
            })
    
    # Get manager names (excluding M21)
    manager_names = []
    if not manager_data.empty:
        for _, row in manager_data.iterrows():
            if row['Manager_ID'] != 'M21':  # Exclude M21 as per requirements
                manager_names.append({
                    'Manager_ID': row['Manager_ID'],
                    'Manager_Name': row['Manager_Name']
                })
    
    return render_template('manager_analysis.html', 
                         players=player_list,
                         managers=manager_names,
                         models=list(MODELS.keys()),
                         years=years)

@app.route('/insights')
def insights_page():
    """Insights page"""
    # Convert DataFrame to list of dictionaries properly
    player_list = []
    if not players_df.empty:
        for _, row in players_df.iterrows():
            player_list.append({
                'Player_ID': row['Player_ID'],
                'Player_Name': row['Player_Name']
            })
    
    return render_template('insights.html', 
                         players=player_list,
                         models=list(MODELS.keys()),
                         years=years)

@app.route('/get_player_info')
def get_player_info():
    """API endpoint to get player information with robust error handling"""
    try:
        player_id = request.args.get('player_id')
        year = request.args.get('year')
        
        print(f"[get_player_info] Request: player_id={player_id}, year={year}")
        
        if not player_id:
            error_msg = "Player ID is required"
            print(f"[get_player_info] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 400
        
        # Check if data files are loaded
        if df_model.empty:
            error_msg = "Model data not available - df_model.csv not loaded"
            print(f"[get_player_info] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 500
        
        # Check if player data is available (either from player.xlsx or player_stat.csv)
        player_name = f'Player {player_id}'  # Default player name
        position = 'Unknown Position'  # Default position
        bmi = 'Unknown BMI'  # Default BMI
        height = 'Unknown Height'  # Default height
        weight = 'Unknown Weight'  # Default weight
        
        print(f"[get_player_info] player_data.empty: {player_data.empty}")
        print(f"[get_player_info] player_stat_data.empty: {player_stat_data.empty}")
        
        if not player_data.empty:
            print(f"[get_player_info] Using player_data")
            # Get player data from player_data DataFrame
            player_matches = player_data[player_data['Player_ID'] == player_id]
            if len(player_matches) == 0:
                error_msg = f"Player {player_id} not found in player data"
                print(f"[get_player_info] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 404
            
            # Get player information
            player_row = player_matches.iloc[0]
            player_name = str(player_row.get('Common_Name', f'Player {player_id}'))
            
            # Get position, BMI, height, and weight if available
            if 'Position' in player_row:
                position = str(player_row['Position'])
            if 'BMI' in player_row:
                bmi = float(player_row['BMI'])
            if 'Height(cm)' in player_row:
                height = float(player_row['Height(cm)'])
            if 'Weight(kg)' in player_row:
                weight = float(player_row['Weight(kg)'])
                
        elif not player_stat_data.empty:
            print(f"[get_player_info] Using player_stat_data as fallback")
            # Get player data from player_stat_data DataFrame as fallback
            player_matches = player_stat_data[player_stat_data['Player_ID'] == player_id]
            print(f"[get_player_info] Found {len(player_matches)} matches for player {player_id}")
            if len(player_matches) == 0:
                error_msg = f"Player {player_id} not found in player data"
                print(f"[get_player_info] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 404
            
            # Get player name from Squad column
            squad_name = str(player_matches.iloc[0].get('Squad', 'Unknown'))
            player_name = f"Player {squad_name}"
        else:
            error_msg = "Player data not available - neither player.xlsx nor player_stat.csv loaded"
            print(f"[get_player_info] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 500
        
        print(f"[get_player_info] Player name: {player_name}")
        
        # Get player model data
        player_model_data = df_model[df_model['Player_ID'] == player_id]
        if len(player_model_data) == 0:
            error_msg = f"Player {player_id} not found in model data"
            print(f"[get_player_info] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 404
        
        # Filter by year if specified
        filtered_data = player_model_data
        response_data = {
            'player_id': player_id,
            'player_name': player_name,
            'selected_year': 'All Years'
        }
        
        year_int = None
        if year and year.strip() and year.lower() not in ['all', 'all years']:
            try:
                year_int = int(year)
                response_data['selected_year'] = str(year_int)
                filtered_data = player_model_data[player_model_data['Year'] == year_int]
                if len(filtered_data) == 0:
                    error_msg = f"No data found for player {player_id} in year {year_int}"
                    print(f"[get_player_info] ERROR: {error_msg}")
                    return jsonify({'error': error_msg}), 404
            except ValueError:
                error_msg = f"Invalid year format: {year}"
                print(f"[get_player_info] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 400
        
        # Get team name (simplified - just get the most common team)
        response_data['team_name'] = 'Unknown Team'  # Default value
        
        if not team_data.empty and 'Player_ID' in team_data.columns:
            team_matches = team_data[team_data['Player_ID'] == player_id]
            if len(team_matches) > 0:
                response_data['team_name'] = str(team_matches.iloc[0].get('Squad', 'Unknown Team'))
        elif not player_stat_data.empty:
            # Fallback to player_stat_data for team information
            player_matches = player_stat_data[player_stat_data['Player_ID'] == player_id]
            if len(player_matches) > 0:
                response_data['team_name'] = str(player_matches.iloc[0].get('Squad', 'Unknown Team'))
        
        # Add player physical information
        response_data['position'] = position
        response_data['bmi'] = bmi
        response_data['height'] = height
        response_data['weight'] = weight
        
        # Get player position (most common position from player_stat.csv)
        # If a year is selected, get the position for that specific year
        # Otherwise, get the overall most common position
        if not player_stat_data.empty:
            player_positions = player_stat_data[player_stat_data['Player_ID'] == player_id]
            
            # If year is selected, filter by year using the Date column
            if year_int and not player_positions.empty and 'Date' in player_positions.columns:
                try:
                    # Convert Date column to datetime and extract year
                    player_positions['Date'] = pd.to_datetime(player_positions['Date'])
                    player_positions = player_positions[player_positions['Date'].dt.year == year_int]
                    
                    # If we have data for this year, get the most common position for this year
                    if len(player_positions) > 0 and 'Pos' in player_positions.columns:
                        position_counts = player_positions['Pos'].value_counts()
                        if len(position_counts) > 0:
                            response_data['position'] = str(position_counts.index[0])
                except Exception as e:
                    print(f"[get_player_info] Error filtering positions by year: {e}")
                    # Fall back to overall most common position
                    if 'Pos' in player_positions.columns:
                        position_counts = player_positions['Pos'].value_counts()
                        if len(position_counts) > 0:
                            response_data['position'] = str(position_counts.index[0])
            elif 'Pos' in player_positions.columns:
                # Get the overall most common position
                position_counts = player_positions['Pos'].value_counts()
                if len(position_counts) > 0:
                    response_data['position'] = str(position_counts.index[0])
        
        # Calculate impact score
        if year and year.strip() and year.lower() not in ['all', 'all years']:
            # Year-specific impact score
            response_data['impact_score'] = round(float(filtered_data['Impact_Score'].mean()), 2)
        else:
            # All years aggregated impact score
            response_data['impact_score'] = round(float(player_model_data['Impact_Score'].mean()), 2)
        
        # Calculate abilities from filtered data (correct mapping)
        abilities = {
            "Passing": round(float(filtered_data['Passing'].mean()), 2),
            "Shooting": round(float(filtered_data['Shooting'].mean()), 2),
            "Creativity": round(float(filtered_data['Creativity'].mean()), 2),
            "Dribbling": round(float(filtered_data['Dribbling'].mean()), 2),
            "Defense": round(float(filtered_data['Defense'].mean()), 2)
        }
        
        response_data['abilities'] = abilities
        
        # Generate player image instead of checking for image files
        image_path = generate_player_image(player_id, player_name)
        response_data['image_exists'] = True
        response_data['image_path'] = image_path
        response_data['is_generated_avatar'] = True
        
        print(f"[get_player_info] SUCCESS: Returning data for {player_id}")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = f"Internal server error: {str(e)}"
        print(f"[get_player_info] EXCEPTION: {error_msg}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': error_msg}), 500

@app.route('/get_recommendations', methods=['POST'])
def get_recommendations():
    """API endpoint to get tactical recommendations with robust error handling"""
    try:
        player_id = request.form.get('player_id')
        model_name = request.form.get('model_name', 'XGBoost')
        year = request.form.get('year')
        
        print(f"[get_recommendations] Request: player_id={player_id}, model={model_name}, year={year}")
        
        if not player_id:
            error_msg = "Player ID is required"
            print(f"[get_recommendations] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 400
        
        # Convert year to int if provided and not empty
        year_int = None
        if year and year.strip() and year.lower() not in ['all', 'all years']:
            try:
                year_int = int(year)
                print(f"[get_recommendations] Using year filter: {year_int}")
            except ValueError:
                error_msg = f"Invalid year format: {year}"
                print(f"[get_recommendations] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 400
        
        # Check if data files are loaded
        if df_model.empty:
            error_msg = "Model data not available - df_model.csv not loaded"
            print(f"[get_recommendations] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 500
        
        # Check if player exists in df_model
        player_model_data = df_model[df_model['Player_ID'] == player_id]
        if len(player_model_data) == 0:
            error_msg = f"Player {player_id} not found in model data"
            print(f"[get_recommendations] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 404
        
        # Get available years for this player
        available_years = sorted(player_model_data['Year'].unique().tolist())
        
        # Filter by year if specified and validate availability
        if year_int:
            if year_int not in available_years:
                error_msg = f"No data found for player {player_id} in year {year_int}. Available years: {available_years}"
                print(f"[get_recommendations] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 404
            
            year_data = player_model_data[player_model_data['Year'] == year_int]
            if len(year_data) == 0:
                error_msg = f"No data found for player {player_id} in year {year_int}"
                print(f"[get_recommendations] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 404
            player_model_data = year_data
        
        print(f"[get_recommendations] Found {len(player_model_data)} records for player {player_id}")
        
        # Get player abilities (correct mapping)
        abilities = {}
        try:
            abilities = {
                'Passing': round(float(player_model_data['Passing'].mean()), 2),
                'Shooting': round(float(player_model_data['Shooting'].mean()), 2),
                'Creativity': round(float(player_model_data['Creativity'].mean()), 2),
                'Dribbling': round(float(player_model_data['Dribbling'].mean()), 2),
                'Defense': round(float(player_model_data['Defense'].mean()), 2)
            }
            print(f"[get_recommendations] Calculated abilities: {abilities}")
        except Exception as e:
            print(f"[get_recommendations] Error calculating abilities: {e}")
            abilities = {}
        
        # Get impact score
        impact_score = None
        try:
            impact_score = round(float(player_model_data['Impact_Score'].mean()), 2)
        except Exception as e:
            print(f"[get_recommendations] Error calculating impact score: {e}")
        
        # Use the SAME shared function for consistency
        shared_result = get_shared_tactical_recommendations(player_id, model_name, year)
        
        if 'error' in shared_result:
            print(f"[get_recommendations] ERROR from shared function: {shared_result['error']}")
            return jsonify({'error': shared_result['error']}), 400
        
        # Extract data from shared result
        recommendations = shared_result['recommendations']
        best_tactic_data = shared_result['best_tactic_data']
        player_model_data = shared_result['player_model_data']
        
        # Get impact over time data
        impact_over_time = []
        try:
            # Group by month/year and calculate mean impact score
            monthly_data = defaultdict(list)
            
            for _, row in player_model_data.iterrows():
                try:
                    date_str = str(row['Date'])
                    impact_score_val = float(row['Impact_Score'])
                    manager_id = str(row['Manager_ID'])
                    
                    # Parse date string to extract month and year
                    date_obj = None
                    for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%Y-%m-%d %H:%M:%S']:
                        try:
                            date_obj = datetime.datetime.strptime(date_str, fmt)
                            break
                        except ValueError:
                            continue
                    
                    if date_obj:
                        month_year = date_obj.strftime('%b %Y')
                        monthly_data[month_year].append({
                            'impact': impact_score_val,
                            'manager_id': manager_id
                        })
                except Exception:
                    continue
            
            # Calculate mean for each month
            for month_year, data_points in monthly_data.items():
                if data_points:
                    mean_impact = sum(d['impact'] for d in data_points) / len(data_points)
                    # Use the most common manager for this month
                    manager_counts = defaultdict(int)
                    for d in data_points:
                        manager_counts[d['manager_id']] += 1
                    most_common_manager = max(manager_counts.items(), key=lambda x: x[1])[0]
                    
                    impact_over_time.append({
                        'month_year': month_year,
                        'impact': round(mean_impact, 2),
                        'manager_id': most_common_manager
                    })
            
            # Sort chronologically
            def date_key(item):
                try:
                    parts = item['month_year'].split(' ')
                    if len(parts) == 2:
                        month_abbr, year = parts
                        month_num = list(calendar.month_abbr).index(month_abbr)
                        return (int(year), month_num)
                    else:
                        return (0, 0)
                except Exception:
                    return (0, 0)
            
            impact_over_time.sort(key=date_key)
            print(f"[get_recommendations] Generated {len(impact_over_time)} impact over time points")
        except Exception as e:
            print(f"[get_recommendations] Error generating impact over time: {e}")
        
        # Get recommended managers based on best tactic
        recommended_managers = []
        if best_tactic_data:
            try:
                manager_formations = get_manager_formations()
                for manager_id, tactics in manager_tactics.items():
                    if manager_id == "M21":
                        continue
                    
                    for tactic_info in tactics:
                        if isinstance(tactic_info, dict) and 'tactic' in tactic_info:
                            if str(tactic_info['tactic']) == str(best_tactic_data['component']):
                                # Get manager name
                                manager_name = str(manager_id)
                                if not manager_data.empty:
                                    manager_matches = manager_data[manager_data['Manager_ID'] == manager_id]
                                    if len(manager_matches) > 0:
                                        manager_name = str(manager_matches.iloc[0].get('Manager_Name', manager_id))
                                
                                tactic_count = int(tactic_info.get('count', 0))
                                total_tactics = sum([t.get('count', 0) for t in tactics if isinstance(t, dict)])
                                score = round(tactic_count / total_tactics if total_tactics > 0 else 0, 3)
                                
                                formations = manager_formations.get(manager_id, [])
                                
                                recommended_managers.append({
                                    'manager_id': str(manager_id),
                                    'manager_name': manager_name,
                                    'score': score,
                                    'formations': formations
                                })
                
                # Sort by score and limit to top 5
                recommended_managers.sort(key=lambda x: x['score'], reverse=True)
                recommended_managers = recommended_managers[:5]
                print(f"[get_recommendations] Found {len(recommended_managers)} recommended managers")
                
            except Exception as e:
                print(f"[get_recommendations] Error processing managers: {e}")
        
        # Add global model performance data to response
        global_model_data = {
            'model_scores': MODEL_PERFORMANCE,
            'best_model': BEST_MODEL,
            'current_model': model_name,
            'is_best_model': model_name == BEST_MODEL
        }
        
        # Prepare response with consistent JSON structure matching frontend expectations
        response_data = {
            'player_id': player_id,
            'player_name': get_player_name(player_id),
            'year': year or "All Years",
            'impact_score': impact_score,
            'abilities': abilities if abilities else {
                'Passing': 0,
                'Shooting': 0,
                'Creativity': 0,
                'Dribbling': 0,
                'Defense': 0
            },
            'best_tactics': [best_tactic_data] if best_tactic_data else [{
                'name': 'No tactics available',
                'score': 0
            }],
            'best_managers': recommended_managers[:3] if recommended_managers else [{
                'manager_id': 'N/A',
                'manager_name': 'No managers available',
                'score': 0
            }],
            # Legacy support for existing frontend code
            'best_tactic': best_tactic_data['component'] if best_tactic_data else None,
            'tactic_value': best_tactic_data['value'] if best_tactic_data else None,
            'recommended_managers': recommended_managers,
            'scores': {
                'impact_score': impact_score,
                'best_tactic_value': best_tactic_data['value'] if best_tactic_data else None
            },
            'recommendations': recommendations,
            'best_component': best_tactic_data,
            'impact': impact_score,
            'impact_over_time': impact_over_time,
            'global_model_performance': global_model_data  # Add global model data
        }
        
        print(f"[get_recommendations] Recommendations for {player_id}: {len(recommendations)} components")
        print(f"[get_recommendations] Response data keys: {list(response_data.keys())}")
        print(f"[get_recommendations] SUCCESS: Returning comprehensive data for {player_id}")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = f"Internal server error: {str(e)}"
        print(f"[get_recommendations] EXCEPTION: {error_msg}")
        return jsonify({'error': error_msg}), 500

@app.route('/get_insights')
def get_insights():
    """API endpoint to get insights data for a player"""
    try:
        player_id = request.args.get('player_id')
        year = request.args.get('year')
        model = request.args.get('model')
        
        print(f"[get_insights] Request: player_id={player_id}, year={year}, model={model}")
        
        if not player_id:
            error_msg = "Player ID is required"
            print(f"[get_insights] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 400
        
        # Convert year to int if provided and not empty
        year_int = None
        if year and year.strip() and year.lower() not in ['all', 'all years']:
            try:
                year_int = int(year)
                print(f"[get_insights] Using year filter: {year_int}")
            except ValueError:
                error_msg = f"Invalid year format: {year}"
                print(f"[get_insights] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 400
        
        # Check if data files are loaded
        if df_model.empty:
            error_msg = "Model data not available - df_model.csv not loaded"
            print(f"[get_insights] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 500
        
        # Check if player exists in df_model
        player_model_data = df_model[df_model['Player_ID'] == player_id]
        if len(player_model_data) == 0:
            error_msg = f"Player {player_id} not found in model data"
            print(f"[get_insights] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 404
        
        # Filter by year if specified
        if year_int:
            year_data = player_model_data[player_model_data['Year'] == year_int]
            if len(year_data) == 0:
                error_msg = f"No data found for player {player_id} in year {year_int}"
                print(f"[get_insights] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 404
            player_model_data = year_data
        
        print(f"[get_insights] Found {len(player_model_data)} records for player {player_id}")
        
        # Get impact over time
        impact_over_time = get_impact_score_over_time(player_id)
        
        # Get manager comparison
        manager_comparison = get_manager_comparison_data(player_id)
        
        # Get seasonal performance
        seasonal_performance = get_seasonal_performance_data(player_id)
        
        # Get tactic frequency
        tactic_frequency = get_tactic_frequency_data(player_id)
        
        # Get ability profile by manager (simplified version)
        manager_abilities = get_ability_profile_by_manager(player_id)
        
        # Prepare response
        response_data = {
            'player_id': player_id,
            'impact_over_time': impact_over_time,
            'manager_comparison': manager_comparison,
            'seasonal_performance': seasonal_performance,
            'tactic_frequency': tactic_frequency,
            'manager_abilities': manager_abilities
        }
        
        print(f"[get_insights] SUCCESS: Returning insights for {player_id}")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = f"Internal server error: {str(e)}"
        print(f"[get_insights] EXCEPTION: {error_msg}")
        return jsonify({'error': error_msg}), 500

def get_ability_profile_by_manager(player_id):
    """Get ability profile for each manager who managed the player"""
    if df_model.empty:
        return []
    
    try:
        player_data_all = df_model[df_model['Player_ID'] == player_id]
        if len(player_data_all) == 0:
            return []
        
        # Get unique managers who actually managed this player
        actual_managers = player_data_all['Manager_ID'].unique()
        print(f"[get_ability_profile_by_manager] Found {len(actual_managers)} managers for player {player_id}")
        
        manager_profiles = []
        colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
        
        for i, manager_id in enumerate(actual_managers):
            if pd.isna(manager_id) or str(manager_id) == 'M21':  # Skip NaN managers and M21 (Others)
                continue
                
            # Get data for this manager and player combination
            manager_player_data = player_data_all[player_data_all['Manager_ID'] == manager_id]
            
            if len(manager_player_data) > 0:
                # Get manager name
                manager_name = str(manager_id)
                if not manager_data.empty:
                    manager_matches = manager_data[manager_data['Manager_ID'] == manager_id]
                    if len(manager_matches) > 0:
                        manager_name = str(manager_matches.iloc[0].get('Manager_Name', manager_id))
                
                # Calculate average abilities under this manager (correct mapping)
                abilities = {
                    'Passing': round(float(manager_player_data['Passing'].mean()), 2),
                    'Shooting': round(float(manager_player_data['Shooting'].mean()), 2),
                    'Creativity': round(float(manager_player_data['Creativity'].mean()), 2),
                    'Dribbling': round(float(manager_player_data['Dribbling'].mean()), 2),
                    'Defense': round(float(manager_player_data['Defense'].mean()), 2)
                }
                
                manager_profiles.append({
                    'manager_id': str(manager_id),
                    'manager_name': manager_name,
                    'abilities': abilities,
                    'color': colors[i % len(colors)],
                    'games_managed': len(manager_player_data),
                    'avg_impact_score': round(float(manager_player_data['Impact_Score'].mean()), 2)
                })
        
        # Sort by average impact score descending
        manager_profiles.sort(key=lambda x: x['avg_impact_score'], reverse=True)
        print(f"[get_ability_profile_by_manager] Generated profiles for {len(manager_profiles)} managers")
        return manager_profiles
        
    except Exception as e:
        print(f"Error getting ability profile by manager: {e}")
        return []



@app.route('/get_impact_over_time')
def get_impact_over_time_endpoint():
    """API endpoint to get impact score over time for a player with manager periods"""
    player_id = request.args.get('player_id')
    
    if not player_id:
        return jsonify({'error': 'Player ID is required'}), 400
    
    impact_over_time = get_impact_score_over_time(player_id)
    manager_periods = get_player_manager_periods(player_id)
    
    return jsonify({
        'impact_over_time': impact_over_time,
        'manager_periods': manager_periods
    })

@app.route('/get_manager_comparison')
def get_manager_comparison_endpoint():
    """API endpoint to get manager comparison data for a player"""
    player_id = request.args.get('player_id')
    
    if not player_id:
        return jsonify({'error': 'Player ID is required'}), 400
    
    try:
        manager_comparison = get_manager_comparison_data(player_id)
        return jsonify({'manager_comparison': manager_comparison})
    except Exception as e:
        print(f"Error getting manager comparison: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/get_seasonal_performance')
def get_seasonal_performance_endpoint():
    """API endpoint to get seasonal performance data for a player"""
    player_id = request.args.get('player_id')
    
    if not player_id:
        return jsonify({'error': 'Player ID is required'}), 400
    
    try:
        seasonal_performance = get_seasonal_performance_data(player_id)
        return jsonify({'seasonal_performance': seasonal_performance})
    except Exception as e:
        print(f"Error getting seasonal performance: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/get_tactic_frequency')
def get_tactic_frequency_endpoint():
    """API endpoint to get best tactic frequency data for a player"""
    player_id = request.args.get('player_id')
    
    if not player_id:
        return jsonify({'error': 'Player ID is required'}), 400
    
    try:
        tactic_frequency = get_tactic_frequency_data(player_id)
        return jsonify({'tactic_frequency': tactic_frequency})
    except Exception as e:
        print(f"Error getting tactic frequency: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/get_tactic_variable_loadings')
def get_tactic_variable_loadings_endpoint():
    """API endpoint to get variable loadings for a tactical component"""
    try:
        component = request.args.get('component')
        
        if not component:
            return jsonify({'error': 'Component parameter is required'}), 400
        
        variable_loadings = get_tactic_variable_loadings(component)
        
        response_data = {
            'component': component,
            'component_name': format_tactic_component_name(component),
            'variable_loadings': variable_loadings,
            'total_variables': len(variable_loadings)
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        print(f"Error getting variable loadings: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/get_manager_analysis')
def get_manager_analysis():
    """API endpoint to get manager analysis data"""
    try:
        manager_id = request.args.get('manager_id')
        model_name = request.args.get('model', 'XGBoost')
        year = request.args.get('year')
        
        if not manager_id:
            return jsonify({'error': 'Manager ID is required'}), 400
        
        # Get manager info
        manager_name = get_manager_name(manager_id)
        
        # Get manager formations
        manager_formations = get_manager_formations()
        formations = manager_formations.get(manager_id, [])
        
        # Get manager's tactical components
        manager_tactical_components = manager_tactics.get(manager_id, [])
        
        # Get top 6 players for this manager (updated from 5)
        top_players = get_top_players_for_manager(manager_id, model_name, year)
        
        # Get manager insights
        insights = get_manager_insights(manager_id, year)
        
        # Get detailed playing style information
        playing_style_details = []
        if manager_tactical_components:
            # Get the primary tactical component for this manager
            best_component = None
            best_count = 0
            
            for component_info in manager_tactical_components:
                if isinstance(component_info, dict) and 'count' in component_info:
                    if component_info['count'] > best_count:
                        best_count = component_info['count']
                        best_component = component_info.get('tactic')
            
            if best_component:
                # Get variable loadings for the best component to determine playing style
                variable_loadings = get_tactic_variable_loadings(best_component)
                playing_style_details = variable_loadings[:5]  # Top 5 style indicators
        
        # Remove formation layout for visualization (as requested)
        # formation_layout = get_formation_layout(manager_id)
        
        response_data = {
            'manager_info': {
                'id': manager_id,
                'name': manager_name,
                'formations': formations,
                'playing_style_details': playing_style_details  # Added playing style details
            },
            'top_players': top_players,
            'formations': get_manager_formation_details(manager_id),
            'insights': insights
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        print(f"Error getting manager analysis: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/get_managers_for_player', methods=['POST'])
def get_managers_for_player():
    """API endpoint to get manager recommendations for a specific player"""
    try:
        print("[get_managers_for_player] Route hit")
        
        player_id = request.form.get('player_id')
        model_name = request.form.get('model_name', 'XGBoost')
        year = request.form.get('year')
        
        print(f"[get_managers_for_player] Request: player_id={player_id}, model={model_name}, year={year}")
        
        if not player_id:
            error_msg = "Player ID is required"
            print(f"[get_managers_for_player] ERROR: {error_msg}")
            return jsonify({'error': error_msg}), 400
        
        # Convert year to int if provided
        year_int = None
        if year and year.strip() and year.lower() not in ['all', 'all years']:
            try:
                year_int = int(year)
                print(f"[get_managers_for_player] Using year filter: {year_int}")
            except ValueError:
                error_msg = f"Invalid year format: {year}"
                print(f"[get_managers_for_player] ERROR: {error_msg}")
                return jsonify({'error': error_msg}), 400
        
        # Get top 5 managers with relevance scoring
        top_managers = get_top_managers_for_player(player_id, year_int, model_name, num_managers=5)
        
        response_data = {
            'player_id': player_id,
            'managers': top_managers,
            'total_managers': len(top_managers)
        }
        
        print(f"[get_managers_for_player] SUCCESS: Returning {len(top_managers)} managers for {player_id}")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = f"Internal server error: {str(e)}"
        print(f"[get_managers_for_player] EXCEPTION: {error_msg}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': error_msg}), 500


@app.route('/get_manager_tactical_profile')
def get_manager_tactical_profile():
    """API endpoint to get manager tactical profile data for visualization"""
    try:
        manager_id = request.args.get('manager_id')
        
        if not manager_id:
            return jsonify({'error': 'Manager ID is required'}), 400
        
        # Get manager insights which includes tactical components
        insights = get_manager_insights(manager_id)
        
        # Return the components data for charting
        components_data = []
        if 'best_components' in insights and insights['best_components']:
            components_data = insights['best_components']
        
        response_data = {
            'manager_id': manager_id,
            'components': components_data
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        print(f"Error getting manager tactical profile: {e}")
        return jsonify({'error': str(e)}), 500


@app.errorhandler(404)
def not_found_error(error):
    """Custom 404 error handler"""
    print(f"[404] Route not found: {request.url}")
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Custom 500 error handler"""
    print(f"[500] Internal server error: {error}")
    return render_template('500.html'), 500


def get_manager_summary_endpoint():
    """API endpoint to get manager-level tactic usage summary"""
    summary = get_manager_summary()
    return jsonify(summary)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)